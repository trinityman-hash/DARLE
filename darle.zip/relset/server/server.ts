// Dependency-free host for Oracle Cloud: static site + POST /api/chat with bounded per-session memory.
import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import { join, extname, normalize } from 'node:path';
import { seeded, type Darle } from '../src/darle.ts';
const PUB = join(process.cwd(), 'public'), PORT = Number(process.env.PORT ?? 8080), MAX = 64, TTL = 20 * 60e3;
const TYPES: Record<string, string> = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css' };
const H = { 'content-security-policy': "default-src 'none'; script-src 'self'; worker-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'", 'x-content-type-options': 'nosniff', 'referrer-policy': 'no-referrer' };
const sessions = new Map<string, { d: Darle; t: number }>();
createServer(async (req, res) => {
  const url = new URL(req.url ?? '/', 'http://x');
  if (url.pathname === '/api/chat') {
    try {
      if (req.method !== 'POST') { res.writeHead(405, H).end(); return; }
      let body = ''; for await (const c of req) { body += c; if (body.length > 4096) { res.writeHead(413, H).end(); return; } }
      const j = JSON.parse(body);
      if (typeof j.text !== 'string' || j.text.length > 500 || !/^[\w-]{8,64}$/.test(j.session)) throw new Error('bad');
      const now = Date.now(); for (const [k, s] of sessions) if (now - s.t > TTL) sessions.delete(k);
      let s = sessions.get(j.session); if (!s) { if (sessions.size >= MAX) sessions.delete(sessions.keys().next().value!); s = { d: seeded(), t: now }; }
      s.t = now; sessions.delete(j.session); sessions.set(j.session, s);
      res.writeHead(200, { ...H, 'content-type': 'application/json', 'cache-control': 'no-store' }).end(JSON.stringify(s.d.chat(j.text)));
    } catch { res.writeHead(400, H).end('{"error":"bad request"}'); }
    return;
  }
  try {
    const p = normalize(url.pathname === '/' ? '/index.html' : url.pathname);
    if (p.includes('..')) throw new Error('path');
    res.writeHead(200, { ...H, 'content-type': TYPES[extname(p)] ?? 'application/octet-stream' }).end(await readFile(join(PUB, p)));
  } catch { res.writeHead(404, H).end('not found'); }
}).listen(PORT, '0.0.0.0', () => console.log(`darle on :${PORT}`));
