const $ = <T extends HTMLElement>(s: string) => document.querySelector(s) as T;
const log = $('#log'), form = $<HTMLFormElement>('#form'), box = $<HTMLTextAreaElement>('#prompt'), send = $<HTMLButtonElement>('#send');
const worker = new Worker('/darle.worker.js'), fmt = new Intl.NumberFormat('en');
const el = (tag: string, cls = '', text = '') => { const e = document.createElement(tag); if (cls) e.className = cls; e.textContent = text; return e; };
function add(n: HTMLElement) { $('#empty')?.remove(); log.append(n); log.scrollTop = log.scrollHeight; }
function stats(s: { dims: number; banks: number; facts: number; bytes: number }) {
  $('#s-d').textContent = fmt.format(s.dims); $('#s-b').textContent = fmt.format(s.banks); $('#s-f').textContent = fmt.format(s.facts);
  $('#s-m').textContent = (s.bytes / 1048576).toFixed(1) + ' MB';
}
function draw(bits: Uint8Array | null) {
  if (!bits) return; const c = $<HTMLCanvasElement>('#matrix'), g = c.getContext('2d')!, S = c.width, cols = 90, u = S / cols;
  g.clearRect(0, 0, S, S); g.save(); g.beginPath(); g.arc(S / 2, S / 2, S / 2 - 3, 0, Math.PI * 2); g.clip();
  g.fillStyle = '#fffdf7'; g.fillRect(0, 0, S, S); g.fillStyle = '#ff4f12';
  for (let j = 0; j < bits.length; j++) if (bits[j]) g.fillRect((j % cols) * u, Math.floor(j / cols) * u, u - 0.6, u - 0.6);
  g.restore(); g.strokeStyle = '#151515'; g.lineWidth = 3; g.beginPath(); g.arc(S / 2, S / 2, S / 2 - 3, 0, Math.PI * 2); g.stroke();
}
worker.onmessage = (e: MessageEvent) => {
  const d = e.data; stats(d.stats); draw(d.bits); send.disabled = false;
  if (d.type !== 'reply') return;
  const r = d.reply, m = el('div', 'msg bot ' + (r.verdict ?? ''), r.text);
  if (r.proof.length) { const det = el('details', 'proof'); det.append(el('summary', '', 'proof'), ...r.proof.map((p: string) => el('div', 'pl', p))); m.append(det); }
  add(m);
};
worker.onerror = () => { add(el('div', 'msg halt', 'The engine could not start in this browser.')); };
function submit() { const t = box.value.trim(); if (!t || send.disabled) return; send.disabled = true; add(el('div', 'msg you', t)); box.value = ''; worker.postMessage({ text: t }); }
form.addEventListener('submit', e => { e.preventDefault(); submit(); });
box.addEventListener('keydown', e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); submit(); } });
$('#clear').onclick = () => log.replaceChildren();
document.querySelectorAll<HTMLButtonElement>('[data-ex]').forEach(b => b.onclick = () => { box.value = b.dataset.ex!; box.focus(); });
