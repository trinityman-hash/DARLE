# DARLE
Hyperdimensional fact memory + multi-hop reasoner + claim verifier. No neural network.
Run: `npm ci && npm test && npm run build && PORT=8080 npm start`  (Node 22+; open the port in the Oracle security list and OS firewall; put Caddy/nginx in front for TLS).
The site works from `public/` alone (engine runs in a browser Web Worker). `POST /api/chat {session,text}` is the server API.
