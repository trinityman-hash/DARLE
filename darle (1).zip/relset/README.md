# DARLE
Hyperdimensional fact memory + multi-hop reasoner + claim verifier. No neural network.

## Render
1. Push this folder to a GitHub repo (Render deploys from Git, not from a zip).
2. Render dashboard: New > Blueprint (uses render.yaml) or New > Web Service with
   Build `npm ci --include=dev && npm run build`, Start `node dist/server.js`, Health check `/healthz`.
3. Choose service type **Web Service** (not Background Worker, not Static Site).

## Anywhere with Node 22+
`npm ci && npm test && npm run build && PORT=8080 npm start`

The page uses the server (`/api/state`, `POST /api/chat`) when it exists and falls back to running the engine in the browser if not (e.g. static hosting).
Memory lives in RAM: a restart or free-tier sleep clears what visitors taught it.
